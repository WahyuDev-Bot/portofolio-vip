WAHYU RAMADHAN — VIP PORTFOLIO

ISI FOLDER
- public/index.html : halaman website
- public/style.css  : desain dan tampilan responsif
- public/script.js  : efek kecil untuk tahun footer
- public/profile.jpg: foto profil

CARA UPLOAD KE HOSTING APA PUN
1. Ekstrak Portofolio-Universal.zip.
2. Buka folder Portofolio lalu buka folder public.
3. Upload ISI folder public (index.html, style.css, script.js, profile.jpg) ke folder web root hosting.
   Folder web root biasanya bernama public_html, htdocs, www, atau wwwroot.
4. Pastikan index.html berada langsung di web root, bukan di dalam folder public.
5. Buka domain dan refresh.

Cocok untuk hosting statis/cPanel/shared hosting, GitHub Pages, Netlify, Cloudflare Pages, dan layanan static hosting lain. Tidak perlu Node.js, npm, database, atau build step untuk versi statis ini.

OPSIONAL
server.js dan package.json disertakan untuk server Node.js, tetapi tidak dibutuhkan pada hosting statis. Pada hosting Node.js, ikuti panduan penyedia hosting.

CATATAN
- Pastikan nama file dan huruf besar/kecil tetap sama, terutama profile.jpg.
- Tampilan tidak bergantung pada Google Fonts atau Font Awesome; font sistem dan simbol bawaan digunakan sebagai fallback.
- Tautan sosial dan data profil mengikuti versi sumber. Edit public/index.html jika ingin mengubahnya.
