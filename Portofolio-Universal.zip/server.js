
const express = require('express');
const path = require('path');

const app = express();
const PORT = Number(
  process.env.SERVER_PORT || process.env.PORT || 3162
);

app.use(express.static(path.join(__dirname, 'public')));

app.get('/health', (req, res) => {
  res.send('Portfolio server is running!');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Portfolio running on port ${PORT}`);
});
