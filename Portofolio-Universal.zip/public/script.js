// Small enhancement only: the site still works if JavaScript is disabled.
document.addEventListener("DOMContentLoaded", function () {
  var year = document.getElementById("year");
  if (year) year.textContent = String(new Date().getFullYear());
});
